/* Activity 1B */

class Act1B	// define class name
{ // open curly brace the beginning of class block

// main program where the program start 
public static void main(String[] args)
{	// open curly brace for main block
//statement to print string
	System.out.println("Hello, my name is Afiq."); System.out.println("\tI’m from Terengganu.");
} //close curly brace for main block
} //end of class with close curly brace for body of block class
