/* Activity 1C */ 
public class Act1C //Defining Class Name 
{ //Open curly brace beginning of class block
//Main program where the program start
public static void main(String[] args) 
{	//Open curly brace for main block 
	int number1 = 11; 	//Declare int variable number1 to 11
	int number2 = 22;	//Declare int variable number2 to 22
	int number3 = 33; 	//Declare int variable number3 to 33
	int number4 = 44;	//Declare int variable number4 to 44
	int number5 = 55;	//Declare int variable number5 to 55
	int sum;			//Declare int sum
	//Formula for calculating sum of 5 numbers
	sum = number1 + number2 + number3 + number4 + number5; 
	//Statement to print sum of 5 numbers
	System.out.print("The sum is "); System.out.println(sum); 
}	//Close curly brace for main block
}	//Close curly brace beginning of class block

