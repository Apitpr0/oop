/* Activity 1F */

class Act3I {
public static void main(String[] args){
	System.out.println("Hello World!");
}
}
