/* Activity 1E */
class Act1E
{
public static void main(String[] args){
	
double price1 = 50.65; 
double total = price1;
System.out.println("Total price is " +total);
}
}