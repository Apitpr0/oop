/* Activity 1D */
class Act1D{
public static void main(String[] args) 
{
	System.out.println ("I Love Java Programming!"); 
	System.out.println ("I know how to write Java Program!"); 
	System.out.println ("It is simple and easy.");
}
}
