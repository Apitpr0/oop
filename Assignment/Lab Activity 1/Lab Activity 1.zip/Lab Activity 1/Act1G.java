/* Activity 1G */

class Act1G {
public static void main(String[] args) { 
int mark = 59;
	if (mark > 50){ // programmer mistake but syntaxly correct 
		System.out.println("PASSED");
	}else{
		System.out.println("FAILED");
}

}
}

